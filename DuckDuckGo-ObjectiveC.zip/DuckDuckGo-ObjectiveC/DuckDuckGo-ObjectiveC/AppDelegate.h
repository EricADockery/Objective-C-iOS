//
//  AppDelegate.h
//  DuckDuckGo-ObjectiveC
//
//  Created by Eric Dockery on 11/11/15.
//  Copyright © 2015 Eric Dockery. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

