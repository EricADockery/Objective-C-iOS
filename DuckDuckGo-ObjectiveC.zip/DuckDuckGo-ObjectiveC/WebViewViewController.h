//
//  WebViewViewController.h
//  DuckDuckGo-ObjectiveC
//
//  Created by Eric Dockery on 11/13/15.
//  Copyright © 2015 Eric Dockery. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WebViewViewController : UIViewController
@property (nonatomic) NSURL *URL;
@end
